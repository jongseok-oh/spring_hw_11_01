package com.ssafy.empapp.model.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.empapp.model.dao.EmpDAO;
import com.ssafy.empapp.model.dto.Emp;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	private EmpDAO empDao;
	
//	@Override
//	public void deleteEmps(int[] empNos) {
//		HashMap<String,Object> map = new HashMap<String,Object>();
//		map.put("array", empNos);
//		empDao.deleteEmps(map);
//	}
	@Override
	public void deleteEmps(int[] empNos) {
		empDao.deleteEmps(empNos);
	}

	@Override
	public List<Emp> getEmps() {
		return empDao.getEmps();
	}

	@Override
	public boolean registerEmp(Emp emp) {
		return empDao.registerEmp(emp) > 0;
	}

	@Override
	public boolean updateEmp(Emp emp) {
		return empDao.updateEmp(emp) >0;
	}

	@Override
	public boolean deleteEmp(int empno) {
		return empDao.deleteEmp(empno) >0;
	}

}













