package com.ssafy.empapp.controller;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.empapp.model.dto.Dept;
import com.ssafy.empapp.model.service.DeptService;

import io.swagger.annotations.ApiOperation;

@RequestMapping("/api/depts")
@RestController
public class DeptRestController  {

	@Autowired
	private DeptService deptService;
	
	@ApiOperation("부서목록데이터를 조회한다." )
	@GetMapping
	protected ResponseEntity<?> getDeptList(@RequestParam(required = false) String dname,
			@RequestParam(required = false) String loc){
		Map<String, Object> conditions = new HashMap<>();
		
		if(dname != null) conditions.put("dname", dname);
		if(loc != null) conditions.put("loc", loc);
		return ResponseEntity.ok(deptService.getDepts(conditions));
	}
	
	
	
	/*
	 * @PostMapping("/search") protected String getDeptListByCondition(@RequestParam
	 * Map<String,Object> condition , Model model) throws Exception {
	 * 
	 * List<Dept> depts = deptService.getDepts(condition);
	 * model.addAttribute("deptList", depts); // request 보관함에 저장
	 * 
	 * return "dept/list"; }
	 */
	
	@GetMapping("/{deptno}")
	protected ResponseEntity<?> getDeptDetail(@PathVariable int deptno){
		Dept d = deptService.getDept(deptno);
		if(d != null) {
			return new ResponseEntity<Dept> (d,HttpStatus.OK);
		}else {
			return new ResponseEntity<Void> (HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/{deptno}/emps")
	protected ResponseEntity<?> getDeptDetailWithEmps(@PathVariable int deptno){
		Dept dept = deptService.getDeptWithEmps(deptno);
		if(dept != null) {
			return ResponseEntity.ok(dept);
		}else return ResponseEntity.notFound().build();
	}


	@PostMapping
	protected ResponseEntity<?> register(@RequestBody Dept dept){
		
		boolean res = deptService.registerDept(dept);
		
		// 4. view page by result
		if(res) {
			return ResponseEntity.created(URI.create("api/depts" + dept.getDeptno())).build();
		}else {			
			return ResponseEntity.internalServerError().build();
		}
	}

//	@PostMapping("/modify.do")
//	protected ModelAndView modify(Dept dept) throws Exception {
//		
//		// 2. call Model(Service)
//		boolean res = deptService.modifyDept(dept);
//		
//		ModelAndView mav = new ModelAndView();
//		// 3. move page by result
//		if(res) {
//			mav.addObject("msg", "부서 수정에 성공하였습니다.");
//		}else {
//			mav.addObject("msg", "부서 수정에 실패하였습니다.");			
//		}
//		mav.setView(new InternalResourceView("/dept/list.do"));
////		mav.setViewName("/dept/list.do"); // /WEB-INF/views//dept/list.do.jsp
//		return mav;
//	}
	
	@PutMapping
	protected ResponseEntity<?> modify(@RequestBody Dept dept){
		
		Dept checkd = deptService.getDept(dept.getDeptno());
		
		if(checkd != null) {
			boolean res = deptService.modifyDept(dept);
			
			if(res) {
				return ResponseEntity.ok(dept);
			}else {
				return ResponseEntity.internalServerError().build();
			}
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@DeleteMapping("/{deptno}")
	protected ResponseEntity<?> remove(@PathVariable int deptno) {
		Dept checkd = deptService.getDept(deptno);
		
		if(checkd != null) {
			boolean res = deptService.deleteDept(deptno);
			
			if(res) {
				return ResponseEntity.noContent().build();
			}else {
				return ResponseEntity.internalServerError().build();
			}
		}else {
			return ResponseEntity.notFound().build();
		}
	}

	/*
	 * @ExceptionHandler(Exception.class) public ResponseEntity<String>
	 * handleException(Exception e,Model model) {
	 * System.out.println("exception 발생 : "+e.getMessage()); return
	 * ResponseEntity.internalServerError(). header("content-type",
	 * "text/plain;charset=utf-8") .body("처리 중 문제가 발생하였습니다. : " + e.getMessage()); }
	 */
	
}
