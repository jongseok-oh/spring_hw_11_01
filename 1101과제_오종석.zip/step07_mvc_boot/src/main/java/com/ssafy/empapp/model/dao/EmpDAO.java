package com.ssafy.empapp.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.empapp.model.dto.Emp;

@Mapper
public interface EmpDAO {

//	void deleteEmps(Map<String,Object> map);
	int deleteEmps(int[] empNos);
	List<Emp> getEmps();
	int registerEmp(Emp emp);
	int updateEmp(Emp emp);
	int deleteEmp(int empno);
}
