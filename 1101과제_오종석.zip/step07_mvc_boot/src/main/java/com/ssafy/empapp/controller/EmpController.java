package com.ssafy.empapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.empapp.model.dto.Emp;
import com.ssafy.empapp.model.service.EmpService;

@RequestMapping("/api/emps")
@RestController
public class EmpController {
	
	@Autowired
	private EmpService empService;
	
	@DeleteMapping
	public ResponseEntity<?> deleteEmps(@RequestParam(required = false) int[] empno) {
		boolean res;
		if(empno != null) empService.deleteEmps(empno);
		return ResponseEntity.noContent().build();
	}
	
	@GetMapping
	public ResponseEntity<?> getEmps(){
		List<Emp> list = empService.getEmps();
		if(list == null || list.isEmpty())
			return ResponseEntity.noContent().build();
		else return ResponseEntity.ok(list);
	}
	
	@PostMapping
	public ResponseEntity<?> registerEmp(@RequestBody Emp emp){
		boolean res = empService.registerEmp(emp);
		if(res) return ResponseEntity.ok(emp);
		else return ResponseEntity.internalServerError().build();
	}
	
	@PutMapping
	public ResponseEntity<?> updateEmp(@RequestBody Emp emp){
		boolean res = empService.updateEmp(emp);
		if(res) return ResponseEntity.ok(emp);
		else return ResponseEntity.internalServerError().build();
	}
}
