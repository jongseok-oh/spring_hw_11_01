package com.ssafy.empapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Step07MvcBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
